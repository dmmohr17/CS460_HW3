import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from sensor_msgs.msg import LaserScan
import time
import math
from collections import deque

# wall following is a hack
# step 1 - scan for a wall - look at architecture reactive control slide - define danger/safe zones
# need to define left, right, and front of robot
# [0 - 5] -> 0 = obstacle, 5 = no obstacle
# PID controller -> error = distance from wall (x(t)-g(t)) -> goal is distance from the wall (ex: stay 3m from wall)
# Can also include random, but easiest is to pick one side with wall following. If something is in front of you,
# ...always turn right (or whichever direction you chose).
# Biggest issue will be corners, will need to solve for that - check architecture slides
# Will need to figure out how to map PID to linear & angular

# Derek's notes
# Turning right at a corner has issues when the wall is extremely small (like a line)
# Issues with obstacles slightly to left or right (increase size of front, left, and right sensors?)
# When robot senses a very small gap, it tries to turn (doesn't have logic for if a gap is too small to fit)
# Logic could use tidying up / refinement
# Need to add PID - may help with tuning
# May want to tune values for follow distance and danger zone
# Add diagonal sensors?

class Walk(Node):
    def __init__(self):
        super().__init__('Walk')
        self.cmd_pub = self.create_publisher(Twist, '/cmd_vel', 10)
        self.subscription_scan = self.create_subscription(LaserScan, '/base_scan', self.sensor_callback, 20)
        self.timer = self.create_timer(0.01, self.timer_callback)

        # Laser scan data
        self.front_distance = float('inf')
        self.left_distance = float('inf')
        self.right_distance = float('inf')
        self.distances = []

        # may want to tune these values if wall crashing occurs
        self.danger_zone = 0.4
        self.follow_distance = 0.6
        self.wall_found = False
        self.start = True
        self.start_helper = 0.0 # helps check for if robot is turning in a circle for too long at init

        # for print statements
        self.tick = 0
        self.ticks = "temp"

        # memory
        self.turningRight = False
        self.turningLeft = False

        # linear PID - will want to tune these values
        self.lin_KP = 0.5
        self.lin_KI = 0.0
        self.lin_KD = 0.1
        self.lin_e = 1
        self.lin_esum = 1
        self.lin_eprev = 1
        self.lin_dedt = 1
        self.lin_PID = 1
        self.lin_u = 1

        # angular pid - will want to tune these values
        self.ang_KP = 1.0
        self.ang_KI = 0.0
        self.ang_KD = 0.2
        self.ang_e = 1
        self.ang_esum = 1
        self.ang_eprev = 1
        self.ang_dedt = 1
        self.ang_PID = 1
        self.lin_u = 1

        self.dt = 0.01
        self.dtHelp = 0.0

        self.move_cmd = Twist()

    # Sensor callback
    def sensor_callback(self, msg: LaserScan):

        # filter sensor values for invalid readings
        def filter_vals(range):
            range = [v for v in range if not math.isinf(v) and not math.isnan(v)]
            return min(range) if range else float('inf')
        
        n = len(msg.ranges)
        front = n // 2
        right = n // 6
        left = n - right

        self.distances = msg.ranges

        # estimates closest obstacles in front, left, and right
        if n > 0:
            self.front_distance = filter_vals(msg.ranges[front - 5 : front + 5])
            self.left_distance  = filter_vals(msg.ranges[left - 5  : left + 5])
            self.right_distance = filter_vals(msg.ranges[right - 5 : right + 5])

    # Timer callback
    def timer_callback(self):
        twist = Twist()
        now = time.time()
        dt = now - getattr(self, 'last_time', now)
        if dt <= 1e-6:
            dt = 0.01
        self.last_time = now

        n = len(self.distances)
        if n == 0:
            return  # no valid data

        # -----------------------------
        # 0. Check right-wall PID activity
        # -----------------------------
        right_center_idx = int(n * 5 / 6)
        right_window = int(3 / getattr(self, 'angle_per_index', 1.0))
        start_idx = max(0, right_center_idx - right_window)
        end_idx = min(n, right_center_idx + right_window + 1)
        right_window_distances = list(self.distances[start_idx:end_idx])
        right_center_distance = self.distances[right_center_idx]

        # Determine if wall alignment PID is active
        if right_center_distance < float('inf') and len(right_window_distances) > 0:
            self.no_wall_timer = 0.0
        else:
            self.no_wall_timer = getattr(self, 'no_wall_timer', 0.0) + dt

        # -----------------------------
        # 1. 90° right-turn fallback
        # -----------------------------
        if self.no_wall_timer >= getattr(self, 'no_wall_timeout', 3.0):
            if not getattr(self, 'turning_right_90', False):
                # Initialize turn
                self.turning_right_90 = True
                front_window = int(5 / getattr(self, 'angle_per_index', 1.0))
                front_idx = n // 2
                self.start_front_cone = self.distances[max(0, front_idx - front_window): min(n, front_idx + front_window + 1)]

            # Apply right turn
            twist.linear.x = 0.0
            twist.angular.z = -0.5  # adjust as needed

            # Check if 90° rotation completed
            right_shift = int(n * 90 / 270)  # 90° to the right in 270° cone
            left_shift_idx = (n // 2 - right_shift) % n
            left_cone = self.distances[max(0, left_shift_idx - 5): min(n, left_shift_idx + 5)]

            if all(abs(a - b) < 0.001 for a, b in zip(self.start_front_cone, left_cone)):
                # Turn complete
                self.turning_right_90 = False
                self.no_wall_timer = 0.0
                twist.angular.z = 0.0

            self.cmd_pub.publish(twist)
            return  # skip PID while turning

        # -----------------------------
        # 2. Forward PID
        # -----------------------------
        front_window = int(5 / getattr(self, 'angle_per_index', 1.0))
        front_window_distances = list(self.distances[max(0, n//2 - front_window): min(n, n//2 + front_window + 1)])
        min_front_distance = min(front_window_distances) if front_window_distances else float('inf')

        target_front_distance = 0.5
        lin_error = min_front_distance - target_front_distance
        self.lin_esum = max(-5, min(5, getattr(self, 'lin_esum', 0) + lin_error * dt))
        lin_dedt = (lin_error - getattr(self, 'lin_eprev', 0)) / dt
        lin_KP, lin_KI, lin_KD = 1.5, 0.0, 0.3
        lin_output = lin_KP * lin_error + lin_KI * self.lin_esum + lin_KD * lin_dedt
        self.lin_eprev = lin_error

        base_speed = getattr(self, 'base_speed', 1.0)
        twist.linear.x = max(0.0, min(base_speed, lin_output))

        # -----------------------------
        # 3. Wall alignment PID (right wall)
        # -----------------------------
        neighbors = right_window_distances[:]
        if right_center_distance in neighbors:
            neighbors.remove(right_center_distance)

        alignment_error = right_center_distance - (sum(neighbors)/len(neighbors) if neighbors else right_center_distance)
        distance_error = right_center_distance - 0.1
        turn_error = distance_error - alignment_error

        self.ang_esum = max(-5, min(5, getattr(self, 'ang_esum', 0) + turn_error * dt))
        ang_dedt = (turn_error - getattr(self, 'ang_eprev', 0)) / dt
        ang_KP, ang_KI, ang_KD = 2.0, 0.0, 0.4
        ang_output = ang_KP * turn_error + ang_KI * self.ang_esum + ang_KD * ang_dedt
        self.ang_eprev = turn_error

        max_turn_speed = 2.0
        twist.angular.z = max(-max_turn_speed, min(ang_output, max_turn_speed))
        self.last_angular_z = twist.angular.z

        self.cmd_pub.publish(twist)







def main(args=None):
    rclpy.init(args=args)
    turtle_controller = Walk()
    rclpy.spin(turtle_controller)
    turtle_controller.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()